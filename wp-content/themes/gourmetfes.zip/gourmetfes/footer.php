<script src="https://use.typekit.net/fya1swr.js"></script>
<script>
try {
    Typekit.load({async: true});
  } catch (e) {
  }
</script>
<!-- <script src="http://code.jquery.com/jquery-1.9.1.min.js"></script> -->
</body>
</html>